// app / auth / login.tsx
import { signIn, signOut, signUp } from 'aws-amplify/auth';
import { useState } from "react";
import { Button, StyleSheet, Text, TextInput, View } from "react-native";


export default function LoginScreen() {
    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");
    const [email, setEmail] = useState("");
    const [user, setUser] = useState(null);

    const IsignUp = async () => {
        try {
            await signUp({
                username,
                password,
                attributes: {
                    email,
                },
            });
            alert("Usuario registrado. Revisa tu correo para confirmar.");
        } catch (err) {
            alert("Error en signup: " + err.message);
        }
    };

    const IsignIn = async () => {

        console.log(`username:${username} password:${password}`);

        try {
            await signIn({ username, password });
            alert("Login correcto");
        } catch (err) {
            alert("Error en login: " + err.message);
        }
    };

    const IsignOut = async () => {
        try {
            await signOut();
            setUser(null);
            alert("Logout correcto");
        } catch (err) {
            alert("Error en logout: " + err.message);
        }
    };

    return (
        <View style={styles.container}>
            <Text style={styles.title}>Amplify Auth Test</Text>

            {!user ? (
                <>
                    <TextInput
                        style={styles.input}
                        placeholder="Username"
                        value={username}
                        onChangeText={setUsername}
                    />
                    <TextInput
                        style={styles.input}
                        placeholder="Email (solo en signup)"
                        value={email}
                        onChangeText={setEmail}
                    />
                    <TextInput
                        style={styles.input}
                        placeholder="Password"
                        secureTextEntry
                        value={password}
                        onChangeText={setPassword}
                    />

                    <Button title="Signup" onPress={IsignUp} />
                    <Button title="Login" onPress={IsignIn} />
                </>
            ) : (
                <>
                    <Text style={styles.logged}>Bienvenido {user.username}</Text>
                    <Button title="Logout" onPress={IsignOut} />
                </>
            )}
        </View>
    );
    // return (
    //     <View>
    //         <SafeAreaView style={{ marginVertical: 400, marginHorizontal: 175 }}>
    //             <LinkPages text='Login' type='Bold' link='../auth/Login' />

    //         </SafeAreaView>
    //     </View>
    // )

}


// import { signIn } from 'aws-amplify/auth';
// import { useState } from "react";
// import { Button, StyleSheet, Text, TextInput, View } from "react-native";

// export default function LoginScreen() {
//     const [username, setUsername] = useState("");
//     const [password, setPassword] = useState("");

//     const handleLogin = async () => {
//         try {
//             const { isSignedIn } = await signIn({
//                 username,
//                 password
//             });


//             console.log("Usuario:", username);
//             console.log("Contraseña:", password);
//             Alert.alert("Login exitoso", `Bienvenido ${username}`);


//         } catch (error) {
//             console.log('error signing in', error);
//             Alert.alert("Error en login", `Por favor verifica tus credenciales`);
//         }
//     };

//     return (
//         <View style={styles.container}>
//             <Text style={styles.title}>Iniciar Sesión</Text>
//             <TextInput
//                 style={styles.input}
//                 placeholder="Usuario"
//                 value={username}
//                 onChangeText={setUsername}
//             />
//             <TextInput
//                 style={styles.input}
//                 placeholder="Contraseña"
//                 value={password}
//                 onChangeText={setPassword}
//                 secureTextEntry={true}
//             />
//             <Button title="Login" onPress={handleLogin} />
//         </View>
//     );
// }

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: "center",
        paddingHorizontal: 20,
    },
    title: {
        fontSize: 24,
        marginBottom: 20,
        textAlign: "center",
    },
    input: {
        height: 50,
        borderColor: "#ccc",
        borderWidth: 1,
        marginBottom: 15,
        paddingHorizontal: 10,
        borderRadius: 5,
    },
});
